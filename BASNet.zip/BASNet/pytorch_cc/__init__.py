import torch
import numpy as np


class CCLoss(torch.nn.Module):
    def __init__(self):
        super(CCLoss, self).__init__()
        self.epsilon=1e-8
    def forward(self, map_pred, map_gtd):
        map_pred = map_pred.float()
        map_gtd = map_gtd.float()

        map_pred = map_pred.view(1, -1)  # change the map_pred into a tensor with n rows and 1 cols
        map_gtd = map_gtd.view(1, -1)  # change the map_pred into a tensor with n rows and 1 cols

        min1 = torch.min(map_pred)
        max1 = torch.max(map_pred)
        map_pred = (map_pred - min1) / (max1 - min1 + self.epsilon)  # min-max normalization for keeping KL loss non-NAN

        min2 = torch.min(map_gtd)
        max2 = torch.max(map_gtd)
        map_gtd = (map_gtd - min2) / (max2 - min2 + self.epsilon)  # min-max normalization for keeping KL loss non-NAN

        map_pred_mean = torch.mean(map_pred)  # calculating the mean value of tensor
        map_pred_mean = map_pred_mean.item()  # change the tensor into a number

        map_gtd_mean = torch.mean(map_gtd)  # calculating the mean value of tensor
        map_gtd_mean = map_gtd_mean.item()  # change the tensor into a number
        # print("map_gtd_mean is :", map_gtd_mean)

        map_pred_std = torch.std(map_pred)  # calculate the standard deviation
        map_pred_std = map_pred_std.item()  # change the tensor into a number
        map_gtd_std = torch.std(map_gtd)  # calculate the standard deviation
        map_gtd_std = map_gtd_std.item()  # change the tensor into a number

        map_pred = (map_pred - map_pred_mean) / (map_pred_std + self.epsilon)  # normalization
        map_gtd = (map_gtd - map_gtd_mean) / (map_gtd_std + self.epsilon)  # normalization

        map_pred_mean = torch.mean(map_pred)  # re-calculating the mean value of normalized tensor
        map_pred_mean = map_pred_mean.item()  # change the tensor into a number

        map_gtd_mean = torch.mean(map_gtd)  # re-calculating the mean value of normalized tensor
        map_gtd_mean = map_gtd_mean.item()  # change the tensor into a number

        CC_1 = torch.sum((map_pred - map_pred_mean) * (map_gtd - map_gtd_mean))
        CC_2 = torch.rsqrt(torch.sum(torch.pow(map_pred - map_pred_mean, 2))) * torch.rsqrt(
            torch.sum(torch.pow(map_gtd - map_gtd_mean, 2))) + self.epsilon
        CC = CC_1 * CC_2
        # print("CC loss is :", CC)
        CC = 1/(CC+self.epsilon)  # the bigger CC, the better

        # L1_loss=torch.mean(torch.abs(map_pred-map_gtd))
        # CC=CC+L1_loss

        return CC


