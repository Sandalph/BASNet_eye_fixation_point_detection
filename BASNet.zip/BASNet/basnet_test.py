import os
from skimage import io, transform
import torch
import torchvision
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms  # , utils
# import torch.optim as optim

import numpy as np
from PIL import Image
import glob

from data_loader import RescaleT
from data_loader import CenterCrop
from data_loader import ToTensor
from data_loader import ToTensorLab
from data_loader import SalObjDataset

from model import BASNet


def normPRED(d):
    ma = torch.max(d)
    mi = torch.min(d)

    dn = (d - mi) / (ma - mi)

    return dn


def save_output(image_name, pred, d_dir):
    print(image_name)
    print(d_dir)
    predict = pred
    predict = predict.squeeze()
    predict_np = predict.cpu().data.numpy()

    im = Image.fromarray(predict_np * 255).convert('RGB')
    img_name = image_name.split("/")[-1]
    image = io.imread(image_name)
    imo = im.resize((image.shape[1], image.shape[0]), resample=Image.BILINEAR)

    pb_np = np.array(imo)

    aaa = img_name.split(".")
    bbb = aaa[0:-1]
    imidx = bbb[0]
    for i in range(1, len(bbb)):
        imidx = imidx + "." + bbb[i]

    imo.save('test_data/test_total/prediction/'+ str(imidx) + '.png')
    print(d_dir + str(imidx) + '.png')


def picture_test(model_dir):
    # --------- 1. get image path and name ---------

    image_dir = './test_data/test_images/'
    prediction_dir = './test_data/test_results/'
    test_image_dirs = ['Action/', 'Affective/',
                       'Art/', 'BlackWhite/',
                       'Cartoon/',
                       'Fractal/', 'Indoor/',
                       'Inverted/',
                       'Jumbled/', 'LineDrawing/',
                       'LowResolution/',
                       'Noisy/', 'Object/',
                       'OutdoorManMade/',
                       'OutdoorNatural/', 'Pattern/',
                       'Random/',
                       'Satelite/', 'Sketch/',
                       'Social/',
                       ]
    image_total_dir='./test_total'
    img_save_list='test_data/prediction/'
    a = os.listdir('test_data/' + image_total_dir)
    image_test=[i for i in a if(i.split('.')[-1]=='jpg')]
    image_test=['test_data/'+'test_total/'+i for i in image_test]


    # --------- 2. dataloader ---------
    # 1. dataload
    test_salobj_dataset = SalObjDataset(img_name_list=image_test, lbl_name_list=[],
                                        transform=transforms.Compose([RescaleT(256), ToTensorLab(flag=0)]))
    test_salobj_dataloader = DataLoader(test_salobj_dataset, batch_size=1, shuffle=False, num_workers=1)

    # --------- 3. model define ---------
    print("...load BASNet...")
    net = BASNet(3, 1)
    net.load_state_dict(torch.load(model_dir))
    if torch.cuda.is_available():
        net.cuda()
    net.eval()

    # --------- 4. inference for each image ---------
    for i_test, data_test in enumerate(test_salobj_dataloader):

        # print("inferencing:", img_name_list[i_test].split("/")[-1])

        inputs_test = data_test['image']
        inputs_test = inputs_test.type(torch.FloatTensor)

        if torch.cuda.is_available():
            inputs_test = Variable(inputs_test.cuda())
        else:
            inputs_test = Variable(inputs_test)

        d1, d2, d3, d4, d5, d6, d7, d8 = net(inputs_test)

        # normalization
        pred = d1[:, 0, :, :]
        pred = normPRED(pred)

        # save results to test_results folder
        save_output('test_data/test_total/'+image_test[i_test].split('/')[-1].split('.')[0]+'.jpg', pred, img_save_list)

        del d1, d2, d3, d4, d5, d6, d7, d8



if __name__ == '__main__':
    picture_test(model_dir='./saved_models/basnet_bsi/basnet_bsi_itr_81200_train_11.846872_tar_1.791115.pth')
