from basnet_score_fast import get_test_score_fast_version as getScore
import os

f=open('./train_ans/cc_kl_score.txt','w')
file='./saved_models/basnet_bsi/'
list=os.listdir('./saved_models/basnet_bsi/')
list_sort=sorted(list,key=lambda x:int(x.split('_')[3]))
cc_final,kl_final=[],[]

for dir in list_sort:
    cc,kl=getScore(file+dir)
    cc_final.append(cc)
    kl_final.append(kl)
    f.write('cc: ' + str(cc)+'\t'+'kl: '+str(kl)+'\t'+'step: '+dir.split('_')[3]+'\n')
    del cc,kl
f.close()

