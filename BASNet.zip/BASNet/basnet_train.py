import torch
import torchvision
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F

from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, utils
import torch.optim as optim
import torchvision.transforms as standard_transforms

import numpy as np
import glob
import time

from basnet_train_score import get_train_score
from basnet_test_score import get_test_score

from data_loader import Rescale
from data_loader import RescaleT
from data_loader import RandomCrop
from data_loader import CenterCrop
from data_loader import ToTensor
from data_loader import ToTensorLab
from data_loader import SalObjDataset

from model import BASNet

import pytorch_ssim
import pytorch_iou
import pytorch_cc
import pytorch_kl

import math

from visdom import Visdom  # the library for visualization
from torch.optim import lr_scheduler
from basnet_score_fast import *

# ------- 1. define loss function --------

bce_with_logits_loss = nn.BCELoss(size_average=True)
ssim_loss = pytorch_ssim.SSIM(window_size=11, size_average=True)
iou_loss = pytorch_iou.IOU(size_average=True)
cc_loss = pytorch_cc.CCLoss()
kl_loss = pytorch_kl.KLLoss()


def bce_ssim_loss(pred, target):
    # print('the max pred is:%s\n' % (float(pred.max())))
    # print('the max target is:%s\n' % (float(target.max())))

    # you may get pred=NAN sometimes!!!!

    bce_out = bce_with_logits_loss(pred, target)
    ssim_out = 1 - ssim_loss(pred, target)
    iou_out = iou_loss(pred, target)
    cc_out = cc_loss(pred, target)
    kl_out = kl_loss(pred, target)

    # print('cc_out:{}'.format(cc_out))
    # print('kl_out:{}'.format(kl_out))

    # loss = bce_out + ssim_out + iou_out

    loss = ssim_out + iou_out  # pay attention: cc_out is negative! so you should make it positive

    return loss, cc_out, kl_out


def total_loss(pred, target):
    '''
    this function is same to the bce_ssim_loss(), the aim is to get ssim_out
    and iou_out!
    '''
    # print('the max pred is:%s\n' % (float(pred.max())))
    # print('the max target is:%s\n' % (float(target.max())))

    # you may get pred=NAN sometimes!!!!

    bce_out = bce_with_logits_loss(pred, target)
    ssim_out = 1 - ssim_loss(pred, target)
    iou_out = iou_loss(pred, target)
    cc_out = cc_loss(pred, target)
    kl_out = kl_loss(pred, target)

    # print('cc_out:{}'.format(cc_out))
    # print('kl_out:{}'.format(kl_out))

    # loss = bce_out + ssim_out + iou_out

    loss = ssim_out + kl_out  # pay attention: cc_out is negative! so you should make it positive

    return ssim_out, iou_out


def muti_bce_loss_fusion(d0, d1, d2, d3, d4, d5, d6, d7, labels_v):
    # Exception detection
    # you may get output=NAN sometimes!!!!
    # tmp=labels_v
    # for output in (d0, d1, d2, d3, d4, d5, d6, d7):
    #     if(float(output.max())<100):
    #         tmp=output
    # for output in (d0, d1, d2, d3, d4, d5, d6, d7):
    #     print('the max output data is:{}'.format(float(output.max())))
    # for output in (d0, d1, d2, d3, d4, d5, d6, d7):
    #     if (float(output.max()) > 100):
    #         output=tmp
    #         print('Pay attention:the num is Inf!!!')
    # for output in (d0, d1, d2, d3, d4, d5, d6, d7):
    #     print('modify!!!:the max output data is:{}'.format(float(output.max())))
    for output in (d0, d1, d2, d3, d4, d5, d6, d7):
        # print(float(output.max()))
        # print('float(output.max()<100?)%s'%(float(output.max())<100))
        # if(float(output.max())<100):
        #     print('yes yes yes yes yes yes')
        if (math.isnan(float(output.max()))):
            return 0, 0, False
    # if()

    cc_out = [0] * 8
    kl_out = [0] * 8

    loss0, cc_out[0], kl_out[0] = bce_ssim_loss(d0, labels_v)
    loss1, cc_out[1], kl_out[1] = bce_ssim_loss(d1, labels_v)
    loss2, cc_out[2], kl_out[2] = bce_ssim_loss(d2, labels_v)
    loss3, cc_out[3], kl_out[3] = bce_ssim_loss(d3, labels_v)
    loss4, cc_out[4], kl_out[4] = bce_ssim_loss(d4, labels_v)
    loss5, cc_out[5], kl_out[5] = bce_ssim_loss(d5, labels_v)
    loss6, cc_out[6], kl_out[6] = bce_ssim_loss(d6, labels_v)
    loss7, cc_out[7], kl_out[7] = bce_ssim_loss(d7, labels_v)
    ssim_out, iou_out = total_loss(d0, labels_v)
    # ssim0 = 1 - ssim_loss(d0,labels_v)

    # iou0 = iou_loss(d0,labels_v)
    # loss = torch.pow(torch.mean(torch.abs(labels_v-d0)),2)*(5.0*loss0 + loss1 + loss2 + loss3 + loss4 + loss5) #+ 5.0*lossa
    # loss = loss0 + loss1 + loss2 + loss3 + loss4 + loss5 + loss6 + loss7#+ 5.0*lossa
    loss = loss0 + loss1 + loss2 + loss3 + loss4 + loss5 + cc_out[0] + kl_out[0] + kl_out[1]
    # loss = loss0 + cc_out[0] + kl_out[0]*10 + kl_out[1]*10
    print("loss0: %3f, loss1: %3f, loss2: %3f, loss3: %3f, loss4: %3f, loss5: %3f,\
 cc_out: %3f, kl_out[0]: %3f, kl_out[1]: %3f" % (loss0.item(), loss1.item(), loss2.item(), loss3.item(),
                                                 loss4.item(), loss5.item(), 1 / (cc_out[0] + 1e-8).item(),
                                                 kl_out[0].item(), kl_out[1].item()))
    # print("BCE: l1:%3f, l2:%3f, l3:%3f, l4:%3f, l5:%3f, la:%3f, all:%3f\n"%(loss1.data[0],loss2.data[0],loss3.data[0],loss4.data[0],loss5.data[0],lossa.data[0],loss.data[0]))

    return loss0, loss, 1 / (cc_out[0] + 1e-8), kl_out[0], ssim_out, iou_out, True


def train_answer_processing(loss, loss0, cc_out, kl_out, ssim_out, iou_out, ite_num, total_ite_num, time, lr):
    #  -------------  this function is to plot the training process  ------------------
    if (ite_num == 1):
        viz.line([loss], [total_ite_num], win='train_loss',
                 opts=dict(title='train_loss', legend=['loss']))
        viz.line([loss0], [total_ite_num], win='train_loss0',
                 opts=dict(title='train_loss0', legend=['loss0']))
        viz.line([cc_out], [total_ite_num], win='cc_out',
                 opts=dict(title='cc_out', legend=['cc_out']))
        viz.line([kl_out], [total_ite_num], win='kl_out',
                 opts=dict(title='kl_out', legend=['kl_out']))
        viz.line([ssim_out], [total_ite_num], win='ssim_out',
                 opts=dict(title='ssim_out', legend=['ssim_out']))
        viz.line([iou_out], [total_ite_num], win='iou_out',
                 opts=dict(title='iou_out', legend=['iou_out']))
        viz.line([[cc_out, kl_out]], [total_ite_num], win='cc&kl',
                 opts=dict(title='cc & kl_out', legend=['cc_out', 'kl_out']))
        viz.line([lr], [total_ite_num], win='lr',
                 opts=dict(title='lr', legend=['lr']))
        # viz.line([[0.0, 0.0]], [0.], win='test', opts=dict(title='test loss&acc.', legend=['loss', 'acc.']))
    else:
        viz.line([loss], [total_ite_num], win='train_loss', update='append')
        viz.line([loss0], [total_ite_num], win='train_loss0', update='append')
        viz.line([cc_out], [total_ite_num], win='cc_out', update='append')
        viz.line([kl_out], [total_ite_num], win='kl_out', update='append')
        viz.line([ssim_out], [total_ite_num], win='ssim_out', update='append')
        viz.line([iou_out], [total_ite_num], win='iou_out', update='append')
        viz.line([[cc_out, kl_out]], [total_ite_num], win='cc&kl', update='append')
        viz.line([lr], [total_ite_num], win='lr', update='append')
    #  ------------- the plot training process end ------------------

    #  -------------  this function is to write the answer to files ------------------
    file_restore = 'train_ans'
    f = open(file_restore + '/train_ans_sum.txt', 'a')
    f.write('total_ite_nums:%d  loss:%.6f  loss0:%.6f  cc_out:%.6f  kl_out:%.6f  \
ssim_out:%.6f  iou_out:%.6f  during_time:%.6f  learning_rate:%.6f\n' % (
        total_ite_num, loss, loss0, cc_out, kl_out, ssim_out, iou_out, time, lr))
    f.close()

    return

def test_answer_processing(cc_score,kl_score,ite_num):
    #  -------------  this function is to plot the training process  ------------------
    if (ite_num == 800):
        viz.line([cc_score], [ite_num], win='cc_score',
                 opts=dict(title='cc_score', legend=['cc_score']))
        viz.line([kl_score], [ite_num], win='kl_score',
                 opts=dict(title='kl_score', legend=['kl_score']))
        viz.line([[cc_score, kl_score]], [ite_num], win='cc&kl',
                 opts=dict(title='cc & kl_score', legend=['cc_score', 'kl_score']))
    else:
        viz.line([cc_score], [ite_num], win='cc_score', update='append')
        viz.line([kl_score], [ite_num], win='kl_score', update='append')
        viz.line([[cc_score, kl_score]], [ite_num], win='cc&kl', update='append')
    #  ------------- the plot training process end ------------------

    #  -------------  this function is to write the answer to files ------------------
    file_restore ='train_ans'
    f = open(file_restore + '/test_ans_sum.txt', 'a')
    f.write('cc_score:%.6f  kl_score:%.6f  ite_num:%d\n' % (cc_score,kl_score,ite_num))
    f.close()

    return


# ------- 2. set the directory of training dataset --------

viz = Visdom()
data_dir = './train_data/'


tra_image_dirs = ['3-Saliency-TrainSet/Stimuli/Action/', '3-Saliency-TrainSet/Stimuli/Affective/',
                  '3-Saliency-TrainSet/Stimuli/Art/', '3-Saliency-TrainSet/Stimuli/BlackWhite/',
                  '3-Saliency-TrainSet/Stimuli/Cartoon/',
                  '3-Saliency-TrainSet/Stimuli/Fractal/', '3-Saliency-TrainSet/Stimuli/Indoor/',
                  '3-Saliency-TrainSet/Stimuli/Inverted/',
                  '3-Saliency-TrainSet/Stimuli/Jumbled/', '3-Saliency-TrainSet/Stimuli/LineDrawing/',
                  '3-Saliency-TrainSet/Stimuli/LowResolution/',
                  '3-Saliency-TrainSet/Stimuli/Noisy/', '3-Saliency-TrainSet/Stimuli/Object/',
                  '3-Saliency-TrainSet/Stimuli/OutdoorManMade/',
                  '3-Saliency-TrainSet/Stimuli/OutdoorNatural/', '3-Saliency-TrainSet/Stimuli/Pattern/',
                  '3-Saliency-TrainSet/Stimuli/Random/',
                  '3-Saliency-TrainSet/Stimuli/Satelite/', '3-Saliency-TrainSet/Stimuli/Sketch/',
                  '3-Saliency-TrainSet/Stimuli/Social/',
                  ]
# tra_image_dirs.extend(test_image_dirs)


tra_label_dirs = ['3-Saliency-TrainSet/FIXATIONMAPS/Action/', '3-Saliency-TrainSet/FIXATIONMAPS/Affective/',
                  '3-Saliency-TrainSet/FIXATIONMAPS/Art/', '3-Saliency-TrainSet/FIXATIONMAPS/BlackWhite/',
                  '3-Saliency-TrainSet/FIXATIONMAPS/Cartoon/',
                  '3-Saliency-TrainSet/FIXATIONMAPS/Fractal/', '3-Saliency-TrainSet/FIXATIONMAPS/Indoor/',
                  '3-Saliency-TrainSet/FIXATIONMAPS/Inverted/',
                  '3-Saliency-TrainSet/FIXATIONMAPS/Jumbled/', '3-Saliency-TrainSet/FIXATIONMAPS/LineDrawing/',
                  '3-Saliency-TrainSet/FIXATIONMAPS/LowResolution/',
                  '3-Saliency-TrainSet/FIXATIONMAPS/Noisy/', '3-Saliency-TrainSet/FIXATIONMAPS/Object/',
                  '3-Saliency-TrainSet/FIXATIONMAPS/OutdoorManMade/',
                  '3-Saliency-TrainSet/FIXATIONMAPS/OutdoorNatural/', '3-Saliency-TrainSet/FIXATIONMAPS/Pattern/',
                  '3-Saliency-TrainSet/FIXATIONMAPS/Random/',
                  '3-Saliency-TrainSet/FIXATIONMAPS/Satelite/', '3-Saliency-TrainSet/FIXATIONMAPS/Sketch/',
                  '3-Saliency-TrainSet/FIXATIONMAPS/Social/',
                  ]
# tra_label_dirs.extend(test_label_dirs)

tra_image_augment = ['augment/Basic/Stimuli/Action/', 'augment/Basic/Stimuli/Affective/',
                     'augment/Basic/Stimuli/Art/', 'augment/Basic/Stimuli/BlackWhite/',
                     'augment/Basic/Stimuli/Cartoon/',
                     'augment/Basic/Stimuli/Fractal/', 'augment/Basic/Stimuli/Indoor/',
                     'augment/Basic/Stimuli/Jumbled/', 'augment/Basic/Stimuli/LineDrawing/',
                     'augment/Basic/Stimuli/LowResolution/',
                     'augment/Basic/Stimuli/Noisy/', 'augment/Basic/Stimuli/Object/',
                     'augment/Basic/Stimuli/OutdoorManMade/',
                     'augment/Basic/Stimuli/OutdoorNatural/', 'augment/Basic/Stimuli/Pattern/',
                     'augment/Basic/Stimuli/Random/',
                     'augment/Basic/Stimuli/Satelite/', 'augment/Basic/Stimuli/Sketch/',
                     'augment/Basic/Stimuli/Social/', 'augment/Brightness/Stimuli/Affective/',
                     'augment/Brightness/Stimuli/Art/', 'augment/Brightness/Stimuli/BlackWhite/',
                     'augment/Brightness/Stimuli/Cartoon/',
                     'augment/Brightness/Stimuli/Fractal/', 'augment/Brightness/Stimuli/Indoor/',
                     'augment/Brightness/Stimuli/Inverted/', 'augment/Brightness/Stimuli/Jumbled/',
                     'augment/Brightness/Stimuli/LowResolution/',
                     'augment/Brightness/Stimuli/Noisy/', 'augment/Brightness/Stimuli/Object/',
                     'augment/Brightness/Stimuli/OutdoorManMade/',
                     'augment/Brightness/Stimuli/OutdoorNatural/', 'augment/Brightness/Stimuli/Pattern/',
                     'augment/Brightness/Stimuli/Random/', 'augment/Brightness/Stimuli/Satelite/',
                     'augment/Brightness/Stimuli/Social/',
                     'augment/GaussBlur/Stimuli/Art/', 'augment/GaussBlur/Stimuli/BlackWhite/',
                     'augment/GaussBlur/Stimuli/Cartoon/',
                     'augment/GaussBlur/Stimuli/Fractal/', 'augment/GaussBlur/Stimuli/Indoor/',
                     'augment/GaussBlur/Stimuli/OutdoorManMade/',
                     'augment/GaussBlur/Stimuli/OutdoorNatural/', 'augment/GaussBlur/Stimuli/Pattern/',
                     'augment/GaussBlur/Stimuli/Random/', 'augment/GaussBlur/Stimuli/Sketch/',
                     'augment/GaussNoise/Stimuli/Action/', 'augment/GaussNoise/Stimuli/Affective/',
                     'augment/GaussNoise/Stimuli/Art/', 'augment/GaussNoise/Stimuli/Cartoon/',
                     'augment/GaussNoise/Stimuli/Indoor/', 'augment/GaussNoise/Stimuli/Inverted/',
                     'augment/GaussNoise/Stimuli/Jumbled/', 'augment/GaussNoise/Stimuli/Object/',
                     'augment/GaussNoise/Stimuli/OutdoorManMade/', 'augment/GaussNoise/Stimuli/OutdoorNatural/',
                     'augment/GaussNoise/Stimuli/Random/', 'augment/GaussNoise/Stimuli/Satelite/',
                     'augment/GaussNoise/Stimuli/Social/',
                     'augment/SP/Stimuli/BlackWhite/', 'augment/SP/Stimuli/LineDrawing/',
                     'augment/SP/Stimuli/Pattern/', 'augment/SP/Stimuli/Sketch/',
                     ]

tra_image_dirs.extend(tra_image_augment)

tra_label_augment = ['augment/Basic/FIXATIONMAPS/Action/', 'augment/Basic/FIXATIONMAPS/Affective/',
                     'augment/Basic/FIXATIONMAPS/Art/', 'augment/Basic/FIXATIONMAPS/BlackWhite/',
                     'augment/Basic/FIXATIONMAPS/Cartoon/',
                     'augment/Basic/FIXATIONMAPS/Fractal/', 'augment/Basic/FIXATIONMAPS/Indoor/',
                     'augment/Basic/FIXATIONMAPS/Jumbled/', 'augment/Basic/FIXATIONMAPS/LineDrawing/',
                     'augment/Basic/FIXATIONMAPS/LowResolution/',
                     'augment/Basic/FIXATIONMAPS/Noisy/', 'augment/Basic/FIXATIONMAPS/Object/',
                     'augment/Basic/FIXATIONMAPS/OutdoorManMade/',
                     'augment/Basic/FIXATIONMAPS/OutdoorNatural/', 'augment/Basic/FIXATIONMAPS/Pattern/',
                     'augment/Basic/FIXATIONMAPS/Random/',
                     'augment/Basic/FIXATIONMAPS/Satelite/', 'augment/Basic/FIXATIONMAPS/Sketch/',
                     'augment/Basic/FIXATIONMAPS/Social/', 'augment/Brightness/FIXATIONMAPS/Affective/',
                     'augment/Brightness/FIXATIONMAPS/Art/', 'augment/Brightness/FIXATIONMAPS/BlackWhite/',
                     'augment/Brightness/FIXATIONMAPS/Cartoon/',
                     'augment/Brightness/FIXATIONMAPS/Fractal/', 'augment/Brightness/FIXATIONMAPS/Indoor/',
                     'augment/Brightness/FIXATIONMAPS/Inverted/', 'augment/Brightness/FIXATIONMAPS/Jumbled/',
                     'augment/Brightness/FIXATIONMAPS/LowResolution/',
                     'augment/Brightness/FIXATIONMAPS/Noisy/', 'augment/Brightness/FIXATIONMAPS/Object/',
                     'augment/Brightness/FIXATIONMAPS/OutdoorManMade/',
                     'augment/Brightness/FIXATIONMAPS/OutdoorNatural/', 'augment/Brightness/FIXATIONMAPS/Pattern/',
                     'augment/Brightness/FIXATIONMAPS/Random/', 'augment/Brightness/FIXATIONMAPS/Satelite/',
                     'augment/Brightness/FIXATIONMAPS/Social/',
                     'augment/GaussBlur/FIXATIONMAPS/Art/', 'augment/GaussBlur/FIXATIONMAPS/BlackWhite/',
                     'augment/GaussBlur/FIXATIONMAPS/Cartoon/',
                     'augment/GaussBlur/FIXATIONMAPS/Fractal/', 'augment/GaussBlur/FIXATIONMAPS/Indoor/',
                     'augment/GaussBlur/FIXATIONMAPS/OutdoorManMade/',
                     'augment/GaussBlur/FIXATIONMAPS/OutdoorNatural/', 'augment/GaussBlur/FIXATIONMAPS/Pattern/',
                     'augment/GaussBlur/FIXATIONMAPS/Random/', 'augment/GaussBlur/FIXATIONMAPS/Sketch/',
                     'augment/GaussNoise/FIXATIONMAPS/Action/', 'augment/GaussNoise/FIXATIONMAPS/Affective/',
                     'augment/GaussNoise/FIXATIONMAPS/Art/', 'augment/GaussNoise/FIXATIONMAPS/Cartoon/',
                     'augment/GaussNoise/FIXATIONMAPS/Indoor/', 'augment/GaussNoise/FIXATIONMAPS/Inverted/',
                     'augment/GaussNoise/FIXATIONMAPS/Jumbled/', 'augment/GaussNoise/FIXATIONMAPS/Object/',
                     'augment/GaussNoise/FIXATIONMAPS/OutdoorManMade/', 'augment/GaussNoise/FIXATIONMAPS/OutdoorNatural/',
                     'augment/GaussNoise/FIXATIONMAPS/Random/', 'augment/GaussNoise/FIXATIONMAPS/Satelite/',
                     'augment/GaussNoise/FIXATIONMAPS/Social/',
                     'augment/SP/FIXATIONMAPS/BlackWhite/', 'augment/SP/FIXATIONMAPS/LineDrawing/',
                     'augment/SP/FIXATIONMAPS/Pattern/', 'augment/SP/FIXATIONMAPS/Sketch/',
                     ]

tra_label_dirs.extend(tra_label_augment)

image_ext = '.jpg'
label_ext = '.jpg'

model_dir = "./saved_models/basnet_bsi_new/"# you may modify the dir of saved_models

epoch_num = 100000
batch_size_train = 10  # you can modify the batch and the LR simultaneously!!!!!!!!!!!!!!!
batch_size_val = 1
train_num = 0
val_num = 0
LR = 0.0001

tra_img_name_list = []

for tra_image_dir in tra_image_dirs:
    tmp = glob.glob(data_dir + tra_image_dir + '*' + image_ext)
    tra_img_name_list.extend(tmp)

tra_lbl_name_list = []

for tra_label_dir in tra_label_dirs:
    tmp = glob.glob(data_dir + tra_label_dir + '*' + image_ext)
    tra_lbl_name_list.extend(tmp)

print("---")
print("train images: ", len(tra_img_name_list))  # 1600 images
print("train labels: ", len(tra_lbl_name_list))  # 1600 image labels
print("---")

train_num = len(tra_img_name_list)

salobj_dataset = SalObjDataset(
    img_name_list=tra_img_name_list,
    lbl_name_list=tra_lbl_name_list,
    transform=transforms.Compose([
        RescaleT(256),
        RandomCrop(224),
        ToTensorLab(flag=0)]))
salobj_dataloader = DataLoader(salobj_dataset, batch_size=batch_size_train, shuffle=True,
                               num_workers=1)  # please modify shuffle is True!!!

# ------- 3. define model --------
# define the net
net = BASNet(3, 1)
if torch.cuda.is_available():
    net.cuda()

# -------  load the pth file --------
PATH = './saved_models/basnet_bsi/basnet_bsi_itr_0_train_0_tar_0.pth'  ## this model is availiable:  basnet_bsi_itr_66000_train_7.860628_tar_0.934676.pth
net.load_state_dict(torch.load(PATH))
old_ite_num = int(PATH.strip().split('_')[5])

# ------- 4. define optimizer --------
print("---define optimizer...")
optimizer = optim.Adam(net.parameters(), lr=LR, betas=(0.9, 0.999), eps=1e-08,
                       weight_decay=0)  # to id NaN ,you must modify the LR!!!
scheduler = lr_scheduler.MultiStepLR(optimizer,milestones=[10000,50000], gamma=0.25)  # modify the learning rate3000

# ------- 5. training process --------
print("---start training...")
ite_num = old_ite_num
running_loss = 0.0
running_tar_loss = 0.0
ite_num4val = 0

for epoch in range(0, epoch_num):
    net.train()

    for i, data in enumerate(salobj_dataloader):
        start_time = time.time()

        ite_num = ite_num + 1
        ite_num4val = ite_num4val + 1

        inputs, labels = data['image'], data['label']

        inputs = inputs.type(torch.FloatTensor)
        labels = labels.type(torch.FloatTensor)

        # wrap them in Variable
        if torch.cuda.is_available():
            inputs_v, labels_v = Variable(inputs.cuda(), requires_grad=False), Variable(labels.cuda(),
                                                                                        requires_grad=False)
        else:
            inputs_v, labels_v = Variable(inputs, requires_grad=False), Variable(labels, requires_grad=False)

        # y zero the parameter gradients
        optimizer.zero_grad()

        # forward + backward + optimize
        d0, d1, d2, d3, d4, d5, d6, d7 = net(inputs_v)
        loss2, loss, cc_out, kl_out, ssim_out, iou_out, Flag = muti_bce_loss_fusion(d0, d1, d2, d3, d4, d5, d6, d7,
                                                                                    labels_v)

        if (Flag == True):
            loss.backward()
            optimizer.step()

            # # print statistics
            running_loss += loss.item()
            running_tar_loss += loss2.item()

        # del temporary outputs and loss
        del d0, d1, d2, d3, d4, d5, d6, d7, loss2, loss, Flag

        end_time = time.time()
        learning_rate = optimizer.state_dict()['param_groups'][0]['lr']

        print("[epoch: %3d/%3d, batch: %5d/%5d, ite: %d] train loss: %3f, tar: %3f, lr: %f, time: %3f\n" % (
            epoch + 1, epoch_num, (i + 1) * batch_size_train, train_num, ite_num, running_loss / ite_num4val,
            running_tar_loss / ite_num4val, learning_rate, end_time - start_time))

        # #  -------------  this function is to plot the training process  ------------------
        train_answer_processing(running_loss / ite_num4val, running_tar_loss / ite_num4val, cc_out.item(),
                                kl_out.item(), ssim_out.item(), iou_out.item(), ite_num4val, ite_num,
                                (end_time - start_time) / batch_size_train, learning_rate)
        # #  -------------  the plot function end  ------------------

        # del cc_out, kl_out

        if ite_num % 100 == 0:  # save model every 2000 iterations
            f=open('./train_ans/cc_kl_score.txt','a')
            model = (model_dir + "basnet_bsi_itr_%d_train_%3f_tar_%3f.pth" % (
                ite_num, cc_out.item(),  kl_out.item()))
            torch.save(net.state_dict(), model)
            running_loss = 0.0
            running_tar_loss = 0.0
            net.train()  # resume train
            ite_num4val = 0

            # cc_score, kl_score = get_test_score(model)
            cc_score, kl_score = get_test_score_fast_version(model)
            test_answer_processing(cc_score,kl_score,ite_num)

            f.write('cc_score: '+str(cc_score)+'  '+'kl_score: '+str(kl_score)+'  '+'step: '+str(ite_num)+'\n')
            f.close()

            # get_train_score(model)
            # get_test_score(model)

        # if ite_num % 8000 == 0:  # save model every 2000 iterations
        #
        #     net.train()
        #     # get_train_score(model)
        #     cc_score,kl_score=get_test_score(model)

        scheduler.step()

print('-------------Congratulations! Training Done!!!-------------')
