import os
from skimage import io, transform
import cv2
import torch
import torchvision
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms#, utils
# import torch.optim as optim

from metric import *

import numpy as np
from PIL import Image
import glob

from data_loader import RescaleT
from data_loader import CenterCrop
from data_loader import ToTensor
from data_loader import ToTensorLab
from data_loader import SalObjDataset

from model import BASNet

def normPRED(d):
	ma = torch.max(d)
	mi = torch.min(d)

	dn = (d-mi)/(ma-mi)

	return dn

def save_output(image_name,pred,d_dir):

	predict = pred
	predict = predict.squeeze()
	predict_np = predict.cpu().data.numpy()

	im = Image.fromarray(predict_np*255).convert('RGB')
	img_name = image_name.split("/")[-1]
	image = io.imread(image_name)
	imo = im.resize((image.shape[1],image.shape[0]),resample=Image.BILINEAR)

	pb_np = np.array(imo)

	aaa = img_name.split(".")
	bbb = aaa[0:-1]
	imidx = bbb[0]
	for i in range(1,len(bbb)):
		imidx = imidx + "." + bbb[i]

	imo.save(d_dir+imidx+'.png')


def get_test_score_fast_version(model_dir):

	# f=open('augmented_train_data/ans.txt','a')

	# --------- 1. get image path and name ---------

	numOfPic = 0
	image_dir = './test_data/'
	prediction_dir = './test_data/'

	test_image_dirs = ['3-Saliency-TestSet/Stimuli/Action/','3-Saliency-TestSet/Stimuli/Affective/',
					  '3-Saliency-TestSet/Stimuli/Art/','3-Saliency-TestSet/Stimuli/BlackWhite/','3-Saliency-TestSet/Stimuli/Cartoon/',
					  '3-Saliency-TestSet/Stimuli/Fractal/','3-Saliency-TestSet/Stimuli/Indoor/','3-Saliency-TestSet/Stimuli/Inverted/',
					  '3-Saliency-TestSet/Stimuli/Jumbled/','3-Saliency-TestSet/Stimuli/LineDrawing/','3-Saliency-TestSet/Stimuli/LowResolution/',
					  '3-Saliency-TestSet/Stimuli/Noisy/','3-Saliency-TestSet/Stimuli/Object/','3-Saliency-TestSet/Stimuli/OutdoorManMade/',
					  '3-Saliency-TestSet/Stimuli/OutdoorNatural/','3-Saliency-TestSet/Stimuli/Pattern/','3-Saliency-TestSet/Stimuli/Random/',
					  '3-Saliency-TestSet/Stimuli/Satelite/','3-Saliency-TestSet/Stimuli/Sketch/','3-Saliency-TestSet/Stimuli/Social/',
					  ]
	test_label_dirs = ['3-Saliency-TestSet/FIXATIONMAPS/Action/','3-Saliency-TestSet/FIXATIONMAPS/Affective/',
					  '3-Saliency-TestSet/FIXATIONMAPS/Art/','3-Saliency-TestSet/FIXATIONMAPS/BlackWhite/','3-Saliency-TestSet/FIXATIONMAPS/Cartoon/',
					  '3-Saliency-TestSet/FIXATIONMAPS/Fractal/','3-Saliency-TestSet/FIXATIONMAPS/Indoor/','3-Saliency-TestSet/FIXATIONMAPS/Inverted/',
					  '3-Saliency-TestSet/FIXATIONMAPS/Jumbled/','3-Saliency-TestSet/FIXATIONMAPS/LineDrawing/','3-Saliency-TestSet/FIXATIONMAPS/LowResolution/',
					  '3-Saliency-TestSet/FIXATIONMAPS/Noisy/','3-Saliency-TestSet/FIXATIONMAPS/Object/','3-Saliency-TestSet/FIXATIONMAPS/OutdoorManMade/',
					  '3-Saliency-TestSet/FIXATIONMAPS/OutdoorNatural/','3-Saliency-TestSet/FIXATIONMAPS/Pattern/','3-Saliency-TestSet/FIXATIONMAPS/Random/',
					  '3-Saliency-TestSet/FIXATIONMAPS/Satelite/','3-Saliency-TestSet/FIXATIONMAPS/Sketch/','3-Saliency-TestSet/FIXATIONMAPS/Social/',
					  ]

	# model_dir = './saved_models/basnet_bsi/basnet_bsi_itr_166200_train_11.774135_tar_1.784897.pth'#this is the dir of model

	image_dir = [image_dir+dir for dir in test_image_dirs]
	prediction_dir = [prediction_dir+dir for dir in test_label_dirs]
	img_name_lists=[]
	label_name_lists=[]


	for dir in image_dir:
		img_name_lists.extend(glob.glob(dir + '*.jpg'))

	for dir in prediction_dir:
		label_name_lists.extend(glob.glob(dir + '*.jpg'))


	final_score_cc = 0
	final_score_kl = 0

	# --------- 2. dataloader ---------
	# for label, img_name_list in enumerate(img_name_lists):
	#1. dataload
	test_salobj_dataset = SalObjDataset(img_name_list = img_name_lists, lbl_name_list = [],transform=transforms.Compose([RescaleT(256),ToTensorLab(flag=0)]))
	test_salobj_dataloader = DataLoader(test_salobj_dataset, batch_size=1,shuffle=False,num_workers=1)

	# --------- 3. model define ---------
	print("...load BASNet...")
	net = BASNet(3,1)
	net.load_state_dict(torch.load(model_dir))
	if torch.cuda.is_available():
		net.cuda()
	net.eval()

	total_score_cc=0
	total_score_kl=0

	# --------- 4. inference for each image ---------
	for i_test, data_test in enumerate(test_salobj_dataloader):

		# print("inferencing:",img_name_list[i_test].split("/")[-1])

		inputs_test = data_test['image']
		inputs_test = inputs_test.type(torch.FloatTensor)

		if torch.cuda.is_available():
			inputs_test = Variable(inputs_test.cuda())
		else:
			inputs_test = Variable(inputs_test)

		d1,d2,d3,d4,d5,d6,d7,d8 = net(inputs_test)

		# normalization
		pred = d1[:,0,:,:]
		pred = normPRED(pred)
		# print(pred.shape)
		# calculate the cc score
		groundTruth=cv2.imread(label_name_lists[i_test],0)
		groundTruth=cv2.resize(groundTruth,(256,256))
		groundTruth=np.array(groundTruth,dtype=np.float32)
		groundTruth=np.expand_dims(groundTruth,0)
		# print(np.array(groundTruth).shape)
		predArray=np.array(pred.cpu().detach())
		score_cc=calc_cc_score(groundTruth, predArray)
		score_kl=KLD(predArray,groundTruth)
		total_score_cc=total_score_cc+score_cc
		total_score_kl=total_score_kl+score_kl

		# print('the pic %s : cc_score is %s'%(i_test,score_cc))
		# print('the pic %s : kl_score is %s' % (i_test, score_kl))

		del d1, d2, d3, d4, d5, d6, d7, d8
		numOfPic+=1


	# name = img_name_list[0].strip().split('/')[-2]
	# print('the %s cc_score is :%s' % (name, total_score_cc / (i_test + 1)))
	# print('the %s kl_score is :%s\n' % (name, total_score_kl / (i_test + 1)))
	final_score_cc = final_score_cc + total_score_cc
	final_score_kl = final_score_kl + total_score_kl

	# f.write('-------------the step %d------------\n'%label)
	# f.write('the %s cc_score is :%s\n' % (name, total_score_cc / (i_test + 1)))
	# f.write('the %s kl_score is :%s\n\n' % (name, total_score_kl / (i_test + 1)))

	print('------------------finals score---------------')
	print('the total cc_score is :%s' % (final_score_cc / numOfPic))##the total test pic num--400!!!
	print('the total kl_score is :%s' % (final_score_kl / numOfPic))##the total test pic num--400!!!

	# f.close()

	# print(numOfPic)
	return (final_score_cc / numOfPic),(final_score_kl / numOfPic)

if __name__ == '__main__':
	model = './saved_models/basnet_bsi/basnet_bsi_itr_116808_train_5.680208_tar_0.780642.pth'  ##the model dir
	get_test_score_fast_version(model)